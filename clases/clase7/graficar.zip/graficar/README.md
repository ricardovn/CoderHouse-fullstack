# Graficar

Simples gráficos utilizando [D3.js](http://d3js.org/).
